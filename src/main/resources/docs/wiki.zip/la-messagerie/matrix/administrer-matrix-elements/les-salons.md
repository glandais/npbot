# Les salons

### Créer un salon  

Cliquer sur le + à droite de Salons (voir capture)

[![capture_d_ecran_2020-12-07_12-48-29.png](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/y1ecbUGBezFemivE-capture-d-ecran-2020-12-07-12-48-29.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/y1ecbUGBezFemivE-capture-d-ecran-2020-12-07-12-48-29.png)

Puis cliquer sur "+ Créer un nouveau salon"


Remplir le formulaire comme ceci : 

[![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/9xlpXw6jQFZPwuhM-capture-d-ecran-2020-12-07-16-08-12.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/9xlpXw6jQFZPwuhM-capture-d-ecran-2020-12-07-16-08-12.png)

Vous avez créé un salon accessible uniquement par invitation. 
L'accès par invitation est le mode le plus confidentiel, cependant, dans la pratique, il demande beaucoup de manipulation de la part de l'admin : 

L'admin doit avoir les identifiants des utilisateurs pour les ajouter au salon, cela peut être fastidieux

### Rendre le salon accessible par lien 

C'est la **solution recommandée**, tout en restant suffisamment sécurisée, pour déployer une conversation avec des personnes novices. 

Le salon précédemment créé doit s'afficher dans la liste des salons


[![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/LdtOLMgEBNnY6EPW-capture-d-ecran-2020-12-07-13-11-26.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/LdtOLMgEBNnY6EPW-capture-d-ecran-2020-12-07-13-11-26.png)

Nous allons modifier les paramètres du salon

[![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/Q5LNAYGNoLsLHj12-capture-d-ecran-2020-12-07-13-12-39.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/Q5LNAYGNoLsLHj12-capture-d-ecran-2020-12-07-13-12-39.png)

#### Adresse locale

**D'abord il faut créer une adresse locale au salon.**  
Dans l'onglet général, aller dans adresses locales
Cliquer sur "En savoir plus"


[![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/vKeQuGb8jsaqpniF-capture-d-ecran-2020-12-07-13-18-57.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/vKeQuGb8jsaqpniF-capture-d-ecran-2020-12-07-13-18-57.png)

Saisir l'adresse souhaitée, puis cliquer sur Ajouter
#### Accès par lien
 
Aller ensuite dans l'onglet "Sécurité & Vie privée" 

Et dans la section "Qui peut accéder au salon ?"

Cocher "Tous ceux qui connaissent le lien du salon, à part les visiteurs"

[![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/RTkdL4Ab5g6tMRzO-capture-d-ecran-2020-12-07-13-22-34.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/RTkdL4Ab5g6tMRzO-capture-d-ecran-2020-12-07-13-22-34.png)

Votre salon est créé et configuré

#### Partager un salon
 
Si votre salon est un salon chiffré privé accessible par lien (voir C.) 
Vous pouvez partager le lien à vos interlocuteurs pour qu'ils puissent le rejoindre. 
* Aller sur le salon 
* Cliquer sur le [![capture_d_ecran_2020-12-07_13-26-37.png](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/9fX1TnCz9Dde3ncn-capture-d-ecran-2020-12-07-13-26-37.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/9fX1TnCz9Dde3ncn-capture-d-ecran-2020-12-07-13-26-37.png) 
* Cliquer sur "Partager le salon"


[![2020-12-07_13-27-54](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/9ZcphQRSSnYLv7xv-capture-d-ecran-2020-12-07-13-27-54.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/9ZcphQRSSnYLv7xv-capture-d-ecran-2020-12-07-13-27-54.png)
[![capture_d_ecran_2020-12-07_13-29-49.png](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/scaled-1680-/MPOGNlFrexkxprYC-capture-d-ecran-2020-12-07-13-29-49.png)](https://wiki.n-peloton.fr/uploads/images/gallery/2023-01/MPOGNlFrexkxprYC-capture-d-ecran-2020-12-07-13-29-49.png)

Copier le lien ou le QR code et partager ce lien à vos amis.