# Administrer Matrix / Element

**Dans ce tuto nous utilisons app.element.io et matrix.org**

### Les salons

[Les salons](https://wiki.n-peloton.fr/books/matrix/page/les-salons)

### Les communautés

TODO