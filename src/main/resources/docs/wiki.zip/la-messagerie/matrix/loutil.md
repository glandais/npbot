# L'outil

## Pourquoi cet outil ?

L'écosystème de messagerie Matrix réponds aux critères suivants :

  * Open source : Liberté d'utilisation / contrôle sur le code du logiciel / Hors GAFAM
  * Décentralisé : Autonomie et résilience du réseau
  * Accessible : Multi plateforme, PC / Mobile
  * Sécurisé : Tunnel de communication chiffré de bout en bout
  * Anonyme : pas besoin de lié son compte à un numéro de numéro de téléphone ou un mail 
  * Ergonomique / Instantané / Réactif  

Plus d'informations ici :
  * [Site Web du reseau Matrix](https://matrix.org/)
  * [Site Web du client Element](https://element.io/why-element)

### Utiliser Matrix/Element

Vous souhaitez simplement utiliser matrix/element, suivez la documentation

[Utiliser Matrix/Element](https://wiki.n-peloton.fr/books/matrix/page/utiliser-matrixelement)

### Administrer Matrix/Element

Vous souhaitez créer des salons, animer des communautés 
Suivez cette documentation 

[Administrer Matrix / Element](https://wiki.n-peloton.fr/books/matrix/page/administrer-matrix-element)