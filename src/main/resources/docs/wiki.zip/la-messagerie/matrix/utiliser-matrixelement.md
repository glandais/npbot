# Utiliser Matrix/Element

## Comment utiliser Matrix / Element ?

Nous recommandons de créer votre compte d'abord depuis un ordinateur. Une fois configuré, vous pourrez utiliser votre smartphone (rdv à l'étape 3).

### Créer son compte sur "Element"


  * Rdv à cette URL : https://app.element.io/#/register
  * Créer login/mot de passe 

Attention : Si vous ne renseignez pas d'adresse mail pour récupérer votre mot de passe, attention a bien enregistrer la clé de récupération de votre compte.


### Utiliser sur votre mobile (Optionnel)


En fonction de votre téléphone vous pouvez télécharger les appli suivantes, puis vous connecter à votre compte créé dans les étapes ci dessus.

  * [Play store](https://play.google.com/store/apps/details?id=im.vector.app) (Android)
  * [Apple Store](https://apps.apple.com/ci/app/element-previously-riot-im/id1083446067) (Apple)

### Rejoindre une communauté 
 
  * Cliquer sur l'URL de la communauté
  * Cliquer sur "Rejoindre la communauté" (en haut à droite)

**ATTENTION :** Fonctionne seulement sur un ordinateur (non implémenté sur l'application mobile)
Mais une fois que vous avez rejoins la communauté, vous aurez accès à la communauté aussi sur votre application mobile


### Rejoindre un salon
 

  * Cliquer sur l'URL du salon ou scanner le QRCode du salon
  * "Ouvrir avec Element" (dans le cas d'un smartphone)
  * Cliquer sur "Rejoindre"


Exemple de salon local : 
[Le comptoir Vélorution nantes](https://matrix.to/#/!UfRqmBqjITmlNlizXG:matrix.org?via=matrix.org)