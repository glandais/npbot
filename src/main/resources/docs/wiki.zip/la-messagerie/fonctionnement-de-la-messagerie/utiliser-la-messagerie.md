# Utiliser la messagerie

### Les salons
Retrouvez les canaux dans le livre [Les salons](https://wiki.n-peloton.fr). 

### L'application mobile

#### Se connecter à l'application mobile

Mettez dans le champs "Spécifier l'URL du serveur" : `https://chat.n-peloton.fr` et dans le "Display name" : `N-Peloton`.  

![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-02/scaled-1680-/ABDnEcjzFdLwkK21-screenshot-20230129-194936-mattermost.png)

Remplissez ensuite les champs Email / Nom d'utilisateur et Mot de passe avec les identifiant que vous créé auparavant.

![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-02/scaled-1680-/EqAyBURASN9jD1xw-screenshot-20230203-174722-mattermost.png)

#### Activer les notifications sur l'application mobile
- Aller dans le menu en cliquant sur le bouton images en haut à droite.  
- Puis cliquer sur Paramètres » Notifications » Mobile  
- Cliquer sur “Envoyer des notifications”  
- Sélectionner “Pour toute activité” Enregistrer  
- Cliquer sur “Déclencher des notificaitons push sur mobile lorsque”  
- Sélectionner “En ligne, apbsent(e) ou hors ligne” Enregistrer

#### Mettre un canal en sourdine

Le comptoir peut être un peu trop bruyant…  
Cliquez sur le canal trop bruyant selon vous. En haut à gauche, cliquez sur les "..." verticaux.
Et cocher “Mettre le canal en sourdine”

### Le site web

#### Mettre un canal en sourdine

Le comptoir peut être un peu trop bruyant…  
Passez votre souris sur le canal trop bruyant dans le menu. A côté du canal devrait apparaitre "..." verticaux.  
![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-02/scaled-1680-/f8w9zkQOBKJO1p1C-capture-decran-2023-02-03-a-17-30-51.png)  
Et cocher “Mettre le canal en sourdine”  
![](https://wiki.n-peloton.fr/uploads/images/gallery/2023-02/scaled-1680-/WHsNWkEXTyavhyqO-capture-decran-2023-02-03-a-17-57-35.png)