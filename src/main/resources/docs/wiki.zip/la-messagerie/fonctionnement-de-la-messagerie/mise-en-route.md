# Mise en route

### Créer son compte

Aller sur [https://chat.n-peloton.fr/signup_email](https://chat.n-peloton.fr/signup_email) et créer un compte.  

Il n'est pas possible de s'inscrire via l'application.  

### Utiliser son compte 

#### Via un navigateur internet

Il est possible d'accéder au chat du n-peloton directement sur votre navigateur internet (Firefox, Chrome etc...) via [https://chat.n-peloton.fr/](https://chat.n-peloton.fr/).

#### Via une application

Vous pouvez également d'accéder au chat du n-peloton via une application dédié : 

- iPhone : [https://apps.apple.com/fr/app/mattermost/id1257222717](https://apps.apple.com/fr/app/mattermost/id1257222717)
- Android : [https://play.google.com/store/apps/details?id=com.mattermost.rn&hl=fr](https://play.google.com/store/apps/details?id=com.mattermost.rn&hl=fr )
- Ordinateur : [https://mattermost.com/download](https://mattermost.com/download)