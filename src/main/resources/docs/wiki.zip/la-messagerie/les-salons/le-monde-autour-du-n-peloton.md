# Le monde autour du N-peloton

#### Est ce que c'est OK?:

Ici on peut : - dénoncer un propos entendu (au sein du groupe ou pas) - proposer une blague, une insulte et valider collectivement qu'elle est ok ! - discuter globalement de sexisme, de racisme, de grossisme, d'homophobie, de putophobie etc.   
[https://chat.n-peloton.fr/np/channels/est-ce-que-cest-ok](https://chat.n-peloton.fr/np/channels/est-ce-que-cest-ok "https://chat.n-peloton.fr/np/channels/est-ce-que-cest-ok")

#### FAQ Safe:

Un canal pour poser des questions et avoir des réponses à celles-ci, sans jugement, sans troll, juste du partage de connaissances, sur tous les sujets possibles et imaginables  
[https://chat.n-peloton.fr/np/channels/faq-safe](https://chat.n-peloton.fr/np/channels/faq-safe "https://chat.n-peloton.fr/np/channels/faq-safe")

#### Hellfest 🤘🏼:

  
[https://chat.n-peloton.fr/np/channels/hellfest](https://chat.n-peloton.fr/np/channels/hellfest "https://chat.n-peloton.fr/np/channels/hellfest")

#### La Couture 🧵:

Ici ça discute machine à coudre et XPAC !  
[https://chat.n-peloton.fr/np/channels/la-couture](https://chat.n-peloton.fr/np/channels/la-couture "https://chat.n-peloton.fr/np/channels/la-couture")

#### La musique dans l'appeau:

Ici on partage ses écoutes du moment et les concerts à venir. Essayons d'éviter l'esbroufe. Essayons.   
[https://chat.n-peloton.fr/np/channels/la-musique-dans-lappeau](https://chat.n-peloton.fr/np/channels/la-musique-dans-lappeau "https://chat.n-peloton.fr/np/channels/la-musique-dans-lappeau")

#### Le comptoir:

  
[https://chat.n-peloton.fr/np/channels/town-square](https://chat.n-peloton.fr/np/channels/town-square "https://chat.n-peloton.fr/np/channels/town-square")

#### Le comptoir !:

[https://wiki.n-peloton.fr/doku.php?id=chat#liste\_des\_canaux](https://wiki.n-peloton.fr/doku.php?id=chat#liste_des_canaux "https://wiki.n-peloton.fr/doku.php?id=chat#liste_des_canaux")  
[https://chat.n-peloton.fr/np/channels/town-square](https://chat.n-peloton.fr/np/channels/town-square "https://chat.n-peloton.fr/np/channels/town-square")

#### N-Daron⋅ne⋅s:

Partage de plans ou sorties avec enfants   
[https://chat.n-peloton.fr/np/channels/n-daronnes](https://chat.n-peloton.fr/np/channels/n-daronnes "https://chat.n-peloton.fr/np/channels/n-daronnes")

#### N-Grimpette 🧗🏽:

Ici, on parle sessions et événements escalade pour alterner avec le bike !  
[https://chat.n-peloton.fr/np/channels/n-grimpette-person\_climbing](https://chat.n-peloton.fr/np/channels/n-grimpette-person_climbing "https://chat.n-peloton.fr/np/channels/n-grimpette-person_climbing")

#### N-LeGrasCestBon:

de faire du gras   
[https://chat.n-peloton.fr/np/channels/cdl](https://chat.n-peloton.fr/np/channels/cdl "https://chat.n-peloton.fr/np/channels/cdl")

#### N-Plantons 🌳🌱:

Permaculture, agroécologie, etc.  
[https://chat.n-peloton.fr/np/channels/n-plantons](https://chat.n-peloton.fr/np/channels/n-plantons "https://chat.n-peloton.fr/np/channels/n-plantons")

#### N-barathon 🍻:

Sortie bar autre que le mercredi  
[https://chat.n-peloton.fr/np/channels/sortie-bar-autre-que-le-mercredi](https://chat.n-peloton.fr/np/channels/sortie-bar-autre-que-le-mercredi "https://chat.n-peloton.fr/np/channels/sortie-bar-autre-que-le-mercredi")

#### Neurchi de peloton:

Ici les sujets concernant le covid-19  
[https://chat.n-peloton.fr/np/channels/cornavibus](https://chat.n-peloton.fr/np/channels/cornavibus "https://chat.n-peloton.fr/np/channels/cornavibus")

#### Vasectomie ou autre moyens de contraception alternatifs:

Parce que la pilule a des concurrents, discussions autour de la contraception masculine  
[https://chat.n-peloton.fr/np/channels/vasectomie-ou-autre-moyens-de-contraception-alternatifs](https://chat.n-peloton.fr/np/channels/vasectomie-ou-autre-moyens-de-contraception-alternatifs "https://chat.n-peloton.fr/np/channels/vasectomie-ou-autre-moyens-de-contraception-alternatifs")