# Le monde autour du vélo

#### 🛠 La Bricole 🔧:

Posez ici vos questions matos, montage et réparation

<abbr title="Read The Fine Manual">RTFM</abbr> : [https://www.sheldonbrown.com/](https://www.sheldonbrown.com/ "https://www.sheldonbrown.com/")  
[https://chat.n-peloton.fr/np/channels/les-conseils-techniques](https://chat.n-peloton.fr/np/channels/les-conseils-techniques "https://chat.n-peloton.fr/np/channels/les-conseils-techniques")

#### Commandes groupées:

Pour réduire les frais de ports et les camions sur la route  
[https://chat.n-peloton.fr/np/channels/commandes-groupees](https://chat.n-peloton.fr/np/channels/commandes-groupees "https://chat.n-peloton.fr/np/channels/commandes-groupees")

#### Les ventes NP:

Pour proposer du matos, troc etc.   
[https://chat.n-peloton.fr/np/channels/les-ventes-np](https://chat.n-peloton.fr/np/channels/les-ventes-np "https://chat.n-peloton.fr/np/channels/les-ventes-np")

#### N-Crampons ( VTC ):

Pour rouler ensemble dans la boue  
[https://chat.n-peloton.fr/np/channels/n-crampons](https://chat.n-peloton.fr/np/channels/n-crampons "https://chat.n-peloton.fr/np/channels/n-crampons")

#### N-Pignon Fixe:

Ici ça discute en non polymutiplié choisie  
[https://chat.n-peloton.fr/np/channels/n-pignon-fixe](https://chat.n-peloton.fr/np/channels/n-pignon-fixe "https://chat.n-peloton.fr/np/channels/n-pignon-fixe")