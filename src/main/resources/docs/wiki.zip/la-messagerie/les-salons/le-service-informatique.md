# Le service informatique

#### Site n-peloton.fr:

Pour remonter les bugs ou proposer des features sur notre outils collaboratif.  
[https://chat.n-peloton.fr/np/channels/biketeam](https://chat.n-peloton.fr/np/channels/biketeam "https://chat.n-peloton.fr/np/channels/biketeam")