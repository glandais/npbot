# Les rides ponctuels

#### BN200 ( world Gravel Championship du 44):

Samedi 11 juin 2022  
[https://chat.n-peloton.fr/np/channels/bn200-world-gravel-championship-du-44](https://chat.n-peloton.fr/np/channels/bn200-world-gravel-championship-du-44 "https://chat.n-peloton.fr/np/channels/bn200-world-gravel-championship-du-44")

#### GFDM du 3 décembre:

  
[https://chat.n-peloton.fr/np/channels/gfdm-du-3-decembre](https://chat.n-peloton.fr/np/channels/gfdm-du-3-decembre "https://chat.n-peloton.fr/np/channels/gfdm-du-3-decembre")

#### NP#450:

orga NP#450  
[https://chat.n-peloton.fr/np/channels/np450-186](https://chat.n-peloton.fr/np/channels/np450-186 "https://chat.n-peloton.fr/np/channels/np450-186")

#### Nantes-Paris 23 décembre:

  
[https://chat.n-peloton.fr/np/channels/nantes-paris-23-decembre](https://chat.n-peloton.fr/np/channels/nantes-paris-23-decembre "https://chat.n-peloton.fr/np/channels/nantes-paris-23-decembre")