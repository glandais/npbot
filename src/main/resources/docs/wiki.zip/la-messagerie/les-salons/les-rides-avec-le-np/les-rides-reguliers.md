# Les rides réguliers

#### Annonce des rides:

SVP Pas de commentaires ici, juste les réactions sont autorisés Le but est d'avoir un fil avec uniquement les annonces pour pouvoir être notifiés   
[https://chat.n-peloton.fr/np/channels/annonce-des-rides](https://chat.n-peloton.fr/np/channels/annonce-des-rides "https://chat.n-peloton.fr/np/channels/annonce-des-rides")

#### Préchauffage central:

pour se rencarder sur les préchauffes du mercredi   
[https://chat.n-peloton.fr/np/channels/prchauffage-central](https://chat.n-peloton.fr/np/channels/prchauffage-central "https://chat.n-peloton.fr/np/channels/prchauffage-central")

#### 200 du vendredi:

Ici on planifie collectivement des sorties de 200km du vendredi  
[https://chat.n-peloton.fr/np/channels/200-du-vendredi](https://chat.n-peloton.fr/np/channels/200-du-vendredi "https://chat.n-peloton.fr/np/channels/200-du-vendredi")

#### Sorties Pâtisserie:

Objectif beurre  
[https://chat.n-peloton.fr/np/channels/sorties-patisserie](https://chat.n-peloton.fr/np/channels/sorties-patisserie "https://chat.n-peloton.fr/np/channels/sorties-patisserie")

#### Sorties autres que mercredi:

Ici on planifie collectivement des sorties   
[https://chat.n-peloton.fr/np/channels/sorties-autres-que-mercredi](https://chat.n-peloton.fr/np/channels/sorties-autres-que-mercredi "https://chat.n-peloton.fr/np/channels/sorties-autres-que-mercredi")