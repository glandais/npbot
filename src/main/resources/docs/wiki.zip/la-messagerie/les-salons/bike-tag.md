# Bike tag

#### 🚲 📸 Bike Tag Life:

c'est là qu'on post les tof de son vélo  
[https://chat.n-peloton.fr/np/channels/bike-tag](https://chat.n-peloton.fr/np/channels/bike-tag "https://chat.n-peloton.fr/np/channels/bike-tag")

#### 🚲 📸 \_/ Hall of fame \\\_ du BikeTag:

Ici, on grave dans la mémoire informatique, les prestigieux résultats de chaque mois !  
[https://chat.n-peloton.fr/np/channels/hall-of-fame-du-biketag](https://chat.n-peloton.fr/np/channels/hall-of-fame-du-biketag "https://chat.n-peloton.fr/np/channels/hall-of-fame-du-biketag")

#### 🚲📸 Bike Tag / Photo du mois:

  
[https://chat.n-peloton.fr/np/channels/bike-tag-photo-du-mois](https://chat.n-peloton.fr/np/channels/bike-tag-photo-du-mois "https://chat.n-peloton.fr/np/channels/bike-tag-photo-du-mois")