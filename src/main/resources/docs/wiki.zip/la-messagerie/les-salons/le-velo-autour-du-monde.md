# Le vélo autour du monde

#### Les gens du voyage à velo:

Ici ça parle vélo voyage bien entendu   
[https://chat.n-peloton.fr/np/channels/les-gens-du-voyage-a-velo](https://chat.n-peloton.fr/np/channels/les-gens-du-voyage-a-velo "https://chat.n-peloton.fr/np/channels/les-gens-du-voyage-a-velo")

#### BRM | Longues distances:

Pour tous autour des BRM  
[https://chat.n-peloton.fr/np/channels/brm-anger](https://chat.n-peloton.fr/np/channels/brm-anger "https://chat.n-peloton.fr/np/channels/brm-anger")

#### Velorution:

ici ça recrute du mappeur pour la velorution   
[https://chat.n-peloton.fr/np/channels/vlorution](https://chat.n-peloton.fr/np/channels/vlorution "https://chat.n-peloton.fr/np/channels/vlorution")

#### Ça va bardet!!:

Ici on parle de courses.   
[https://chat.n-peloton.fr/np/channels/tibopino](https://chat.n-peloton.fr/np/channels/tibopino "https://chat.n-peloton.fr/np/channels/tibopino")