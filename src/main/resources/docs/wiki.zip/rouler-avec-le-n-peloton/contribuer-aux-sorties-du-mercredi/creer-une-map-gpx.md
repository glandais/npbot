# Créer une map GPX

Dans un premier temps, il faut créer une map.

#### Les principes de base, du mercredi soir :

- Adapter en fonction de la saison, +/- 5km
- Départ des Fonderies
- Arrivée dans le bar décidé collégialement sur la conversation privée “Orga Mercredi” de la messagerie privée NP.
- Regarder la météo (un départ vent face pour un retour vent dos est toujours plus agréable)


| | Départ | Vitesse | Distance | D+ |
|-|--|----|--|----|
| G1 | 20h30 | 34 km/h | 65km  | 400m
G2 |	20h30 |	32 km/h | 65km | 400m
G3 |	20h30 |	30 km/h | 60km | 350m
FastPack |	19h30 |	27 km/h | 60km | 350m
Chill |	19h30 |	25 km/h | 50km | 350m
SuperChill | 	19h30 |	20 km/h | 40km | 200m
Gravel | 	19h45 |	23 km/h | 45km | 300m
Chill Gravel | 	19h30 |	20 km/h | 40km | 200m

Valeurs données à titre indicatif (en gros 2h de ride)

#### Les outils pour creer une map :

##### Brouter :

- [https://brouter.damsy.net/latest/](https://brouter.damsy.net/latest/)
- [https://brouter.de/brouter-web/](https://brouter.de/brouter-web/)
- [https://brouter.m11n.de/](https://brouter.de/brouter-web/)
- [https://bikerouter.de/](https://brouter.de/brouter-web/)

Brouter est un outil open source qui permet de tracer des itinéraires vélo (et autre)
Il permet de configurer un profil (liste déroulante en haut à gauche), nous préconisons “Vélo de route (fable traffic)” ou “RoadBike (Minimized traffic)”.  
Il permet également d'afficher les itinéraires cyclables.

Une fois votre trace finalisée vous pouvez l'exporter en gpx.

#### Autres outils :

##### Graphhopper :

[https://graphhopper.com/maps/](https://graphhopper.com/maps/)

##### [gpx.studio](https://gpx.studio) :

Outil permettant de créer/modifier/vérifier son tracé

- calcul de l'itinéraire avec “Racing bike” ou “Moutain bike”
- affichage de la heatmap Strava
- affichage du cadastre (voies publiques sans numéro de parcelle)
- fond de carte IGN
- affiche le type de route sur le profil d'élévation

Aide / manuel d'utilisation

##### [Windy](https://www.windy.com) :

Permet de superposer le GPX avec une carte météo

- Clique droit sur la carte
- Distance & planification
- Select .gpx file


D'autres outils sont présents dans la section [Outil de cartographie](https://wiki.n-peloton.fr/books/outil-de-cartographie), mais nous recommandons ceux ci dessus.