# Pousser la map sur le site NP

#### Avoir les droits

Nécessite un compte Strava  
Faire la demande sur la conversation privée “orga ride” de la messagerie privée NP, ou à n.peloton@gmail.com  
En spécifiant son compte Strava.  

#### Se logger  

Pour contribuer il faut se connecter en cliquant sur le bouton “Connexion” en haut à droite du site. Utiliser la connexion Strava sinon ca ne marchera pas.

Autoriser n-peloton.fr à se connecter à vos données Strava, promis on en abusera pas ;)  

#### Publier une map

Une fois loggé (il faut parfois se déconnecter/reconnnecter), vous verrez apparaître un bouton “Gérer” dans le menu en haut. Ensuite aller dans le menu "[Maps](https://www.n-peloton.fr/login?requestUri=/n-peloton/admin/maps&requestUri=/n-peloton/admin/maps?requestUri=/n-peloton/admin/maps)". Puis mettre le GPX et cliquer sur “Nouvelle map”

Renseignez :
- changer le nom de la map (mettre le numéro NP incrémenté si c'est un mercredi soir)
- le type (gravel ou route)
- les tags (ex : Sortie Hebdo si c'est un mercredi soir)

Cliquez sur “Enregistrer”  
Et voilà vous avez publier votre première map, bravo !  

#### Créer un ride

Une fois les maps publiées (ou avant qu'importe l'ordre) il faut créer le ride.

Dans le menu Gérer > Rides, créer un nouveau ride en utilisant le bon template (N-Peloton pour mercredi, Raymond pour dimanche). C'est important d'utiliser le template car cela permet de conserver la numérotation à jour.

Mettre la date de publication à mardi à 12h puis remplir.

Sélectionner “Fonderies” pour le départ. Pour l'arrivée, la liste des bars est classée dans l'ordre inversement chronologique depuis la dernière visite (le plus anciennement visité en haut) sauf pour ceux qui n'ont jamais été visités qui finissent tout en bas.

Si besoin de créer un nouveau lieu pour le finish, utiliser le bouton Gérer > Lieux.