# Feux et intersections

Si vous êtes devant ne passez pas à l'orange.
Pour vous suivre, les autres derrière seraient obligés de passer au rouge et de se mettre en danger.  
Par ailleurs sur une intersection, même si vous avez la priorité, ne foncez pas tête baissée… Assurez-vous que les automobilistes vous ont bien vu.