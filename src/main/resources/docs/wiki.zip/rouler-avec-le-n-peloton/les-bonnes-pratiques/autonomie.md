# Autonomie

Nous recommandons d'être autonome sur les aspects suivants quand tu viens rouler:

- Appareil pour suivre la trace du parcours du début à la fin (GPS, tél, etc)
- Nécessaire de réparation (multi-tool, chambre à air, etc)
- Ravitaillement en cas de fringale
- Une lumière avant puissante pour rouler de nuit sur route non-éclairée, ainsi qu'une lumière arrière bien visible (ouais on insiste)