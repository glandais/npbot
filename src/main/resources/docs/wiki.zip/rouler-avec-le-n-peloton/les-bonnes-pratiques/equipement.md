# Equipement

Il est impératif d'avoir un vélo en bon état (capable de freiner notamment), gants, casques, lumières sont des éléments de sécurité individuels mais aussi pour le groupe.

Les lumières doivent te permettre de rouler de nuit sur chaussée non-éclairée seul.e