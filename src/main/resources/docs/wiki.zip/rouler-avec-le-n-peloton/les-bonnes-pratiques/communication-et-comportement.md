# Communication et comportement

70 % des chutes proviennent d’un manque de vigilance dans le groupe !  
Sur le vélo, n’oubliez pas de communiquer gestuellement ET à voix haute.  
Voici une [petite vidéo](https://youtu.be/DdY7GkfsqRc "https://youtu.be/DdY7GkfsqRc") qui t'explique les gestes courants

Prévenez les coéquipier⋅e⋅s des dangers (trous, ralentisseur…) et autres obstacles qui surgissent en pointant du doigt.  
Les personnes en tête du groupe doivent donner les consignes et prévenir les autres.  
Évitez au maximum les changements et écarts de direction ou les freinages brusques.  
Prévenir en levant le bras si l'on doit s'arrêter ou ralentir afin que les personnes derrière puissent anticiper