# Application Garmin

L'application [Garmin](https://wiki.n-peloton.fr/attachments/4) est disponible [ici](https://apps.garmin.com/fr-FR/apps/7743f8a1-cb5f-478d-a9a7-4ea48b915cd8)

[![e660b362-07c6-48d2-a3a3-ca1a0cfbad78.png](https://wiki.n-peloton.fr/uploads/images/gallery/2024-09/scaled-1680-/ytsnf9834FwsCWGW-e660b362-07c6-48d2-a3a3-ca1a0cfbad78.png)](https://apps.garmin.com/fr-FR/apps/7743f8a1-cb5f-478d-a9a7-4ea48b915cd8)