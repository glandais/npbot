# Le réseau ferré

## Un peu partout

Un site pour connaitre les différentes lignes de chemin de fer qui existe sur fond d'OpenStreetmap [https://signal.eu.org/osm/](https://signal.eu.org/osm/)

Le site [Openrailwaymap](https://www.openrailwaymap.org/)

## En France

Un seul PDF caché sur le [site de la SNCF](https://www.sncf-reseau.com/medias-publics/2023-09/POSTER%20RFN_2023.pdf).  

Et quelques personnes ont réalisé une [carte google map](https://www.google.com/maps/d/viewer?mid=1sDybsb22LYXcAEr7MNrQnkZJues83FZH&) des trains en France

Nous avons aussi trouvé [l'Atlas du Réseau Ferré de France](https://wiki.n-peloton.fr/attachments/1) (PDF))

Une [carte en temps réel des trains en France](https://carto.graou.info/47.07018/1.41379/6.27792/0/0)

Une [autre carte](https://velotrain.fr/) vous permet de voir le temps "moyen" pour rejoindre la gare la plus proche selon votre position / itinéraire