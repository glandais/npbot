# S'organiser avec les trains

Il existe quelques sites pour planifier ses itinéraires en train, mais très peu pour les planifier avec un vélo.

Voici une petite liste pour pouvoir voyager en train avec son vélo sans le démonter : 

* [Horaire de train](https://www.horaires-de-trains.fr/horaires-ter.html) (sélectionnez l'option TER)
* [Deutch Bahn](https://www.bahn.com/fr) (sélectionnez l'option "Train régionaux uniquement")