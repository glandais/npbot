# OsmAnd (Android)

OsmAnd est une application de cartographie et de navigation sur Android et iOS. Elle est disponible en versions gratuite et payante. La version Android est libre. Les cartes utilisées sont celles d'OpenStreetMap. Elles peuvent être stockées localement et l'application peut fonctionner hors-ligne. [Wikipedia](https://fr.wikipedia.org/wiki/OsmAnd)

Une petite vidéo de présentation très complète a été réalisé (en anglais cependant) : [https://www.youtube.com/watch?v=2ctb_S9Fb-8](https://www.youtube.com/watch?v=2ctb_S9Fb-8)

Télécharger sur Playstore (Android) : [https://play.google.com/store/apps/details?id=net.osmand&hl=fr&gl=US](https://play.google.com/store/apps/details?id=net.osmand&hl=fr&gl=US). 

Télécharger sur FDroid (version complète) (Android) : [https://f-droid.org/fr/packages/net.osmand.plus/](https://f-droid.org/fr/packages/net.osmand.plus/)

Télécharger sur AppStore (IOS) : [https://apps.apple.com/us/app/osmand-maps-travel-navigate/id934850257](https://apps.apple.com/us/app/osmand-maps-travel-navigate/id934850257)