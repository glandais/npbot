# Bike-router (BRouter)

Cet outil est libre et opensource. Il existe donc plusieurs instances : 

- [https://brouter.damsy.net/latest/](https://brouter.damsy.net/latest/)
- [https://brouter.de/brouter-web/](https://brouter.de/brouter-web/)
- [https://brouter.m11n.de/](https://brouter.de/brouter-web/)
- [https://bikerouter.de/](https://brouter.de/brouter-web/)

Brouter est un outil open source qui permet de tracer des itinéraires vélo (et autre)
Il permet de configurer un profil (liste déroulante en haut à gauche), nous préconisons “Vélo de route (fable traffic)” ou “RoadBike (Minimized traffic)”.  
Il permet également d'afficher les itinéraires cyclables.

Une fois votre trace finalisée vous pouvez l'exporter en gpx.