# GPX studio

Également Opensource, [gpx.studio](https://gpx.studio) permet de créer/modifier/vérifier son tracé

- calcul de l'itinéraire avec “Racing bike” ou “Moutain bike”
- affichage de la heatmap Strava
- affichage du cadastre (voies publiques sans numéro de parcelle)
- fond de carte IGN
- affiche le type de route sur le profil d'élévation