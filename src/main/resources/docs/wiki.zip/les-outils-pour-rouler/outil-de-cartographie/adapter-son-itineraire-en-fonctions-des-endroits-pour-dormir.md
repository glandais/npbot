# Adapter son itinéraire en fonctions des endroits pour dormir

## Camping
Cet outil se base sur Openstreetmap pour les fonds de carte, [Datatourisme](https://info.datatourisme.fr/) et les utilisateurs pour les données. 

Vous pouvez, dans [cet outil](https://randocamping.touteslatitudes.fr), importer votre GPX pour afficher les campings, zone de bivouac etc sur votre parcours, mais aussi afficher les lignes de trains.

[randocamping.touteslatitudes.fr](https://randocamping.touteslatitudes.fr)

## Gites d'étapes
Un site qui répertorie les gites d'étapes : [https://www.gites-refuges.com/www/index.htm](https://www.gites-refuges.com/www/index.htm)