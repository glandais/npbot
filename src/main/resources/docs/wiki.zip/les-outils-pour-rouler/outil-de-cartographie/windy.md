# Windy

[Windy](https://www.windy.com) permet de superposer le GPX avec une carte météo  

Pour cela : 
1. Clique droit sur la carte
2. Distance & planification
3. Select .gpx file